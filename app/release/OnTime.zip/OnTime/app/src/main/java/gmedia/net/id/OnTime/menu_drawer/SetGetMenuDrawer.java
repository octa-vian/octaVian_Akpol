package gmedia.net.id.OnTime.menu_drawer;

public class SetGetMenuDrawer {
    private String textMenu;
    private Integer iconMenu;

    public String getTextMenu() {
        return textMenu;
    }

    public void setTextMenu(String textMenu) {
        this.textMenu = textMenu;
    }

    public Integer getIconMenu() {
        return iconMenu;
    }

    public void setIconMenu(Integer iconMenu) {
        this.iconMenu = iconMenu;
    }
}
