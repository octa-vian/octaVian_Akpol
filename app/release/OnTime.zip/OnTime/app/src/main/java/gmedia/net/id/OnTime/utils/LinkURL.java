package gmedia.net.id.OnTime.utils;

public class LinkURL {
//    public static String BaseURLLocalHost = "http://192.168.20.4/hrd.absensi/";
    public static String BaseURLLocalHost = "http://gmedia.bz/ontime/";
    public static String UrlLogin = BaseURLLocalHost + "Rest/auth";
    public static String ScanAbsen = BaseURLLocalHost + "Rest_Scan/scan";
    public static String Profile = BaseURLLocalHost + "Rest_Profile/";
    public static String ListJadwalKerja = BaseURLLocalHost + "Rest_Jadwal/index";
    public static String listPengumuman = BaseURLLocalHost + "Rest_News/index";
    public static String addCuti = BaseURLLocalHost + "Rest_Cuti/add_cuti";
    public static String viewCuti = BaseURLLocalHost + "Rest_Cuti/index";
    public static String addIjin = BaseURLLocalHost + "Rest_Ijin/add_ijin";
    public static String viewIjin = BaseURLLocalHost + "Rest_Ijin/index";
    public static String viewAbsensi = BaseURLLocalHost + "Rest_Absensi/index";
    public static String viewLembur = BaseURLLocalHost + "Rest_Lembur/index";
	public static String viewApprovalCuti = BaseURLLocalHost + "Rest_Cuti/view_approval";
	public static String viewApprovalIjin = BaseURLLocalHost + "Rest_Ijin/view_approval";
	public static String approvalCuti = BaseURLLocalHost + "Rest_Cuti/approve_cuti";
	public static String approvalIjin = BaseURLLocalHost + "Rest_Ijin/approve_ijin";
	public static String infoGaji = BaseURLLocalHost + "Rest_Gaji/";
	public static String viewScanlog = BaseURLLocalHost + "Rest_Scan/view_scan";
	public static String sisaCuti = BaseURLLocalHost + "Rest_Cuti/jumlah_cuti";
	public static String gantiPassword = BaseURLLocalHost + "Rest/change_password";
	public static String viewTerlambat = BaseURLLocalHost + "Rest_Absensi/terlambat";
	public static String upVersion = BaseURLLocalHost + "Rest/version";
	public static String urlIpPublic = "https://api.ipify.org";
}
